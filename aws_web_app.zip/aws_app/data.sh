#!/bin/bash
export HTTP_PROXY=http://10.4.1.37:3128 #proxy address
export HTTPS_PROXY=http://10.4.1.37:3128
yum -y update
yum -y install httpd
echo "Website Application is Working !" > /var/www/html/index.html
systemctl start httpd
systemctl enable httpd



# #!/bin/bash
# export HTTP_PROXY=http://10.4.1.37:3128
# export HTTPS_PROXY=http://10.4.1.37:3128
# yum -y install postgresql15.x86_64
# yum -y install git
# yum -y install dotnet-runtime-6.0.x86_64
# yum -y install dotnet-sdk-6.0.x86_64

# echo "CREATE TABLE MOVIE( ID int4 NOT NULL GENERATED ALWAYS AS IDENTITY, \"Name\" VARCHAR NOT NULL, \"Year\" int4 NOT NULL, genre VARCHAR NOT NULL, CONSTRAINT movie_pk PRIMARY KEY (\"Name\", \"Year\") );" > postgres.sql

# echo "INSERT INTO MOVIE (\"Name\",\"Year\",genre) VALUES ('Matrix Reloaded',2022,'Action'),('Matrix',1999,'Action');" >> postgres.sql

# PGPASSWORD=rbspassword psql --host=rbs-rds-20230405124751453900000001.cr0aqduewhau.ap-southeast-1.rds.amazonaws.com --port=5432 --dbname=rbs_rds_db --user=rbsuser -a -q -f postgres.sql 

# mkdir -p /app/hello
# cd /app/hello
# git clone https://github.com/raghavan-mk/helloworld.git
# cd helloworld/api
# IPADDR=`ifconfig | grep inet | grep broadcast | grep -v init6 | tr -s " " | cut -d " " -f3`
# # nohup dotnet run --urls="http://10.0.12.3" &

# nohup dotnet run --urls="http://${IPADDR}" &