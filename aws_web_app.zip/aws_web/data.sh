#!/bin/bash
export HTTP_PROXY=http://10.4.1.37:3128
export HTTPS_PROXY=http://10.4.1.37:3128
yum -y update
yum -y install httpd
echo "Website is Working !" > /var/www/html/index.html
systemctl start httpd
systemctl enable httpd

# #!/bin/bash
# export HTTP_PROXY=http://10.4.1.37:3128
# export HTTPS_PROXY=http://10.4.1.37:3128
# yum -y update
# # yum -y install httpd
# yum -y install nginx

# echo "Website is Working !" > /var/www/html/index.html

# cat <<EOF > print.sh
# {
#   "ConnectionStrings": {
#     "pgpsql":"Server=localhost;Port=5432;Database=postgres;User=rhgfghj;Password=klihjweagrolifu"
#   },
#   "Logging": {
#     "LogLevel": {
#       "Default": "Information",
#       "Microsoft.AspNetCore": "Warning"
#     }
#   },
#   "AllowedHosts": "*"
# }

# EOF

# systemctl start nginx
# systemctl enable nginx
 